import React from "react";
import WorldcupLandingPage from "../Components/WorldcupLandingPage/WorldcupLandingPage";

const Dashboard = () => {
  return (
    <>
      <WorldcupLandingPage />
    </>
  );
};

export default Dashboard;
