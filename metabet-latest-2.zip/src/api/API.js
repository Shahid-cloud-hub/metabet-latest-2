export const contactFormApi =
  "https://clever-gold-pinafore.cyclic.app/api/metaBetContact";

export const getBannersData =
  "https://dull-puce-wildebeest-belt.cyclic.app/getBanner";
// export const contactFormApi = "http://localhost:5000/api/metaBetContact";
