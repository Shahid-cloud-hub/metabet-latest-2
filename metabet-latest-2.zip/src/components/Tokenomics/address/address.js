import txid from "../../../assets/images/Token/txid.webp";
import removeicon from "../../../assets/images/Token/removeicon.webp";
export const users = [
    { id: 1, icon1: txid, name: "efrgiu37v4chieief4o " , icon2: removeicon},
    { id: 2, icon1: txid, name: "efrgiu37v4chieief4o ", icon2: removeicon },
    { id: 3, icon1: txid, name: "efrgiu37v4chieief4o ", icon2: removeicon },
  ]