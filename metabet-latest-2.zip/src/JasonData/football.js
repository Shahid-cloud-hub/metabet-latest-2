export const footBallMainBanners = [
  {
    backgroundImg:
      "https://res.cloudinary.com/dfjmnwwan/image/upload/v1677047762/Football-upcoming/Group_483089_bv1xua.png",
    route_path: "champions-league",
  },
  {
    backgroundImg:
      "https://res.cloudinary.com/dfjmnwwan/image/upload/v1677047762/Football-upcoming/Group_483090_bv5for.png",
    route_path: "ligue-1",
  },
  {
    backgroundImg:
      "https://res.cloudinary.com/dfjmnwwan/image/upload/v1677047762/Football-upcoming/Group_483230_xaragw.png",
    route_path: "laliga",
  },
  {
    backgroundImg:
      "https://res.cloudinary.com/dfjmnwwan/image/upload/v1677047762/Football-upcoming/Group_483094_wcvcbr.png",
    route_path: "premier-league",
  },
  {
    backgroundImg:
      "https://res.cloudinary.com/dfjmnwwan/image/upload/v1677047762/Football-upcoming/Frame_1000003639_mdpod1.png",
    route_path: "serie-a",
  },
  {
    backgroundImg:
      "https://res.cloudinary.com/dfjmnwwan/image/upload/v1677047762/Football-upcoming/Frame_1000003639_1_f5ygfr.png",
    route_path: "bundesliga",
  },
];
